﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task3
{
    interface IFigure
    {
        float Area { get;}
        float Perimeter { get;}
    /*    string ToString();
        bool Equals(object obj);
        int GetHashCode();*/
    }
}
